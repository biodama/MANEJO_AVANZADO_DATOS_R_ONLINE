
#####################
# CASO ESTUDIO
#####################


# 1. Importa los datos del caso estudio (datos.caso.estudio.txt)

# 2. Crea una base de datos que contenga los hombres casados fumadores de la base de datos y exportalo con el nombre "datos_hombres_casados.txt".

# 3. Crea las siguentes variables tal y como se indica:

# 3.1. estado.civil.new: Es igual a la variable estado.civil pero donde la categoría de "Casado" debe llamarse "cas", la de "Soltero", "sol", y la de "Divorciado", "div".

# 3.2. grupo.edad: Una variable categórica (factor) de la edad, con los siguientes grupos; "[0,25)"  "[25,60)"  "[60,85]"

# 3.3. fecha.CM: variable tipo fecha a partir de la variable "fdiag_cm"

# 3.4. fecha.CP: variable tipo fecha a partir de la variable "fdiag_cp"

# 3.5. fecha.DF: variable tipo fecha a partir de la variable "fdef"

# 3.6. fecha.DF_new: variable tipo caracter a partir de la variable "fdef" de tal manera que figure solo el mes y el año como en el siguiente ejemplo (May/1980)

# 3.7. dias.df.CM: número de días entre la fecha de diagnostico de cáncer de mama (fecha.CM) y la fecha de defunción (fecha.DF)

# 3.8. dias.df.CP: número de días entre la fecha de diagnostico de cáncer de próstata (fecha.CP) y la fecha de defunción (fecha.DF)

# 3.9. semanas.df.CM: número de semanas entre la fecha de diagnostico de cáncer de mama (fecha.CM) y la fecha de defunción (fecha.DF)

# 3.10. semanas.df.CP: número de semanas entre la fecha de diagnostico de cáncer de próstata (fecha.CP) y la fecha de defunción (fecha.DF)

# 3.11. fecha_analisis_CM: variable tipo fecha resultante de restar 5 días a la fecha.CM

# 3.12. fecha_analisis_CP: variable tipo fecha resultante de restar 3 días a la fecha.CP

# 4. Comprueba el número de caracteres de la variable ID de los datos

# 5. Comprueba si existen valores repetidos en la variable ID de los datos

# 6. Crea una nueva variable llamada "ID_num" que corresponda a los valores que tiene la variable ID antes del primer "--".

# 7. Crea una nueva variable llamada "CCAA" que corresponda a los caracteres entre "--" y "_" de los valores de la variable ID.

# 8. Crea una nueva variable llamada "seccion" que corresponda a los valores que tiene la variable ID después del caracter "_".

# 9. Crea una nueva variable llamada "ID_new" que sea igual a la variable ID, pero donde se hayan eliminado los caracteres "--" y "_".

# 10. Crea una nueva variable llamada Cancer.secundario que tome el valor de "Si", cuando en la variable complicaciones se mencione algo referido a Cáncer. Y "No" en cualquiera de los otros casos.

# 11. Crea una funcion llamada "depuracion" que revise una base de datos (como la del curso) y que si encuentra algún registro hombre, casado con nivel de estudios bajo, muestre el siguiente mensaje "REVISA LA BASE DE DATOS" y proporcione los identificadores de los registros que cumplan esta condición.

# 12. Crea una variable llamada "sobrepeso" que tenga valores de Sí cuando el peso>=70 y "No" cuando el peso sea <70.

# 13. Importa las bases de datos "datos_caso_estudio_genes.txt" y los datos "datos.caso.biomarcadores.txt"

# 14. Recodifica SNPS de la base de datos de genes de tal forma que los genotipos de los SNPs no tengan espacios vacios en sus valores.

# 15. Une las tres bases de datos (datos, genes y biomarcadores) en una sola base de datos.

# 16. Crea una base de datos en formato "long" con tres variables: ID de registro, biomarcador medido y valor de este.

