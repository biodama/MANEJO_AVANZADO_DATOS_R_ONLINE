
#####################
# CASO ESTUDIO
#####################

# 1. Importa los datos del caso estudio (datos.caso.estudio.txt)

rm(list=ls())
gc()

datos<-read.table("/Users/pfernandezn/Desktop/datos.caso.estudio.txt",header=T,sep="\t",stringsAsFactors=F)

# 2. Crea una base de datos que contenga los hombres casados fumadores y con cáncer de próstata de la base de datos y exportalo con el nombre "datos_hombres_casados.txt".

unique(datos$"sexo")
unique(datos$"estado.civil")
unique(datos$"fumador")
unique(datos$"cancer.prostata")

datos_esp<-datos[c(datos$"sexo"%in%"Hombre" & datos$"estado.civil"%in%"Casado" & datos$"fumador"%in%"Si"& datos$"cancer.prostata"%in%"Si"), ]

# Otra forma: datos_esp<- subset(datos, c(datos$"sexo"%in%"Hombre" & datos$"estado.civil"%in%"Casado" & datos$"fumador"%in%"Si" & datos$"cancer.prostata"%in%"Si"))

dim(datos_esp)

write.table(datos_esp,file="/Users/pfernandezn/Desktop/datos.esp.txt",sep="\t",quote=F,row.names=F)



# 3. Crea las siguentes variables en los datos importados tal y como se indica:

# 3.1. estado.civil.new: Es igual a la variable estado.civil pero donde la categoría de "Casado" debe llamarse "cas", la de "Soltero", "sol", y la de "Divorciado", "div".


datos$"estado.civil.new"<-as.factor(datos$estado.civil)

levels(datos$"estado.civil.new")<-c("cas","div","sol")

datos$"estado.civil.new"<-as.character(datos$"estado.civil.new")

table(datos$"estado.civil.new",datos$"estado.civil")



# 3.2. grupo.edad: Una variable categórica (factor) de la edad, con los siguientes grupos; "[0,25)"  "[25,60)"  "[60,85]"

datos$"grupo.edad"<-cut(datos$edad,breaks=c(0,25,60,85),right=F,include.lowest=T)

table(datos$"grupo.edad")


# 3.3. fecha.CM: variable tipo fecha a partir de la variable "fdiag_cm"

class(datos$"fdiag_cm")
datos$"fechas.CM" <- as.Date(datos$"fdiag_cm")
class(datos$"fechas.CM")
datos$"fechas.CM"[1:6]

# 3.4. fecha.CP: variable tipo fecha a partir de la variable "fdiag_cp"

class(datos$"fdiag_cp")
datos$"fechas.CP" <- as.Date(datos$"fdiag_cp", format="%d.%m.%y")
class(datos$"fechas.CP")
datos$"fechas.CP"[1:6]

# 3.5. fecha.DF: variable tipo fecha a partir de la variable "fdef"

class(datos$"fdef")
datos$"fechas.DF" <- as.Date(datos$"fdef",format="%Y.%m.%d")
class(datos$"fechas.DF")
datos$"fechas.DF"[1:6]


# 3.6. fecha.DF_new: variable tipo caracter a partir de la variable "fdef" de tal manera que figure solo el mes y el año como en el siguiente ejemplo (May/1980)

datos$"fecha.DF_new"<-as.character(format(datos$"fechas.DF",format="%b/%Y"))


# 3.7. dias.df.CM: número de días entre la fecha de diagnostico de cáncer de mama (fecha.CM) y la fecha de defunción (fecha.DF)

datos$"dias.df.CM"<-difftime(datos$"fechas.DF",datos$"fechas.CM",units="days") 
class(datos$"dias.df.CM")
head(datos[,c("ID","fechas.DF","fechas.CM","dias.df.CM")])


# 3.8. dias.df.CP: número de días entre la fecha de diagnostico de cáncer de próstata (fecha.CP) y la fecha de defunción (fecha.DF)

datos$"dias.df.CP"<-difftime(datos$"fechas.DF",datos$"fechas.CP",units="days") 
class(datos$"dias.df.CP")
head(datos[,c("ID","fechas.DF","fechas.CP","dias.df.CP")])



# 3.9. semanas.df.CM: número de semanas entre la fecha de diagnostico de cáncer de mama (fecha.CM) y la fecha de defunción (fecha.DF)

datos$"semanas.df.CM"<-difftime(datos$"fechas.DF",datos$"fechas.CM",units="week") 
class(datos$"semanas.df.CM")
head(datos[,c("ID","fechas.DF","fechas.CM","dias.df.CM","semanas.df.CM")])


# 3.10. semanas.df.CP: número de semanas entre la fecha de diagnostico de cáncer de próstata (fecha.CP) y la fecha de defunción (fecha.DF)


datos$"semanas.df.CP" <- difftime(datos$"fechas.DF",datos$"fechas.CP",units="week") 
class(datos$"semanas.df.CP")
head(datos[,c("ID","fechas.DF","fechas.CP","dias.df.CP","semanas.df.CP")])



# 3.11. fecha_analisis_CM: variable tipo fecha resultante de restar 5 días a la fecha.CM

datos$"fecha_analisis_CM" <- datos$"fechas.CM"-5

# 3.12. fecha_analisis_CP: variable tipo fecha resultante de restar 3 días a la fecha.CP

datos$"fecha_analisis_CP" <- datos$"fechas.CP"-3


# 4. Comprueba el número de caracteres de la variable ID de los datos

nchar(datos$ID)
unique(nchar(datos$ID))
table(nchar(datos$ID),exclude=NULL)


# 5. Comprueba si existen valores repetidos en la variable ID de los datos

length(unique(datos$"ID"))


# 6. Crea una nueva variable llamada "ID_num" que corresponda a los valores que tiene la variable ID antes del primer "--".

# Una manera
valores<-list()
for(i in 1:dim(datos)[1]){
	
	print(i)
	valores[[i]]<-unlist(strsplit(datos$ID[i],split="--"))[1]
	
	
	
}
datos$"ID_num"<-unlist(valores)



# Otra manera
library("plyr")
datos$"ID_num"<-ldply(strsplit(datos$ID,split="--"))[,1]



# 7. Crea una nueva variable llamada "CCAA" que corresponda a los caracteres entre "--" y "_" de los valores de la variable ID.


# Una forma

valores1<-list()
for(i in 1:dim(datos)[1]){
	
	print(i)
	valores1[[i]]<-unlist(strsplit(datos$ID[i],split=c("--"))[2]
	
	
	
}
valores1<-unlist(valores1)

valores2<-list()
for(i in 1:dim(datos)[1]){
	
	print(i)
	valores2[[i]]<-unlist(strsplit(valores1[i],split="_"))[1]
	
	
	
}
valores2<-unlist(valores2)

datos$"CCAA"<-valores2


# Otra forma

library("plyr")
datos$"CCAA"<-ldply(strsplit(ldply(strsplit(datos$"ID",spli=c("--")))[,2],split="_"))[,1]


# 8. Crea una nueva variable llamada "seccion" que corresponda a los valores que tiene la variable ID después del caracter "_".

library("plyr")
datos$"seccion"<-ldply(strsplit(ldply(strsplit(datos$"ID",spli=c("--")))[,2],split="_"))[,2]



# 9. Crea una nueva variable llamada "ID_new" que sea igual a la variable ID, pero donde se hayan eliminado los caracteres "--" y "_".

datos$"ID_new"<-gsub("--","",datos$"ID")
datos$"ID_new"<-gsub("_","",datos$"ID_new")

# 10. Crea una nueva variable llamada Cancer.secundario que tome el valor de "Si", cuando en la variable complicaciones se mencione algo referido a Cáncer. Y "No" en cualquiera de los otros casos.

datos$"Cancer.secundario"<-NA
datos$"Cancer.secundario"[!is.na(datos$"complicaciones")]<-"No"
datos$"Cancer.secundario"[grep("Cancer",datos$"complicaciones")]<-"Si"
datos$"Cancer.secundario"[grep("cancer",datos$"complicaciones")]<-"Si"
datos$"Cancer.secundario"[grep("Cáncer",datos$"complicaciones")]<-"Si"
datos$"Cancer.secundario"[grep("cáncer",datos$"complicaciones")]<-"Si"

table(datos$"Cancer.secundario")

head(datos[datos$"Cancer.secundario"%in%"Si",])

# 11. Crea una funcion llamada "depuracion" que revise una base de datos (como la del curso) y que si encuentra algún registro hombre, casado con nivel de estudios bajo, muestre el siguiente mensaje "REVISA LA BASE DE DATOS" y proporcione los identificadores de los registros que cumplan esta condición.


depuracion<-function(x){
	
	mirar<-x[c(x$"sexo"%in%"Hombre" & x$nivel.estudios%in%"Bajo" & x$estado.civil%in%"Casado"),]
	
	if(dim(mirar)[1]>0){
		
		print("REVISA LA BASE DE DATOS")
		ids_mirar<-mirar$ID
	}
	if(dim(mirar)[1]==0){
	
		ids_mirar<-NA
	
	}
	
	ids_mirar
	
}


depuracion(datos)


# 12. Crea una variable llamada "sobrepeso" que tenga valores de Sí cuando el peso>=64 y "No" cuando el peso sea <64.

datos$"sobrepeso"<-NA
sum(is.na(datos$peso))
datos$"sobrepeso"[datos$peso>=80]<-"Si"
datos$"sobrepeso"[datos$peso<80]<-"No"

table(datos$"sobrepeso",exclude=NULL)



# 13. Importa las bases de datos "datos_caso_estudio_genes.txt" y los datos "datos.caso.biomarcadores.txt"

genes<-read.table("/Users/pfernandezn/Desktop/datos.caso.estudio_genes.txt",header=T,sep="\t",stringsAsFactors=F)

biomarcadores<-read.table("/Users/pfernandezn/Desktop/datos.caso.estudio_biomarcadores.txt",header=T,sep="\t",stringsAsFactors=F)


# 14. Recodifica SNPS de la base de datos de genes de tal forma que los genotipos de los SNPs no tengan espacios vacios en sus valores.

head(genes)

genes[,-1]<-apply(genes[,-1],2,function(x) gsub(" ","",x))

head(genes)

# 15. Une las tres bases de datos (datos, genes y biomarcadores) en una sola base de datos.

length(intersect(datos$"ID",genes$"ID"))
setdiff(datos$"ID",genes$"ID")
setdiff(genes$"ID",datos$"ID")

length(datos$"ID")
length(unique(datos$"ID"))
length(genes$"ID")
length(unique(genes$"ID"))

datos1<-merge(datos,genes,by="ID")



length(intersect(datos1$"ID",biomarcadores$"ID"))
setdiff(datos$"ID",biomarcadores$"ID")
setdiff(biomarcadores$"ID",datos$"ID")

length(datos$"ID")
length(unique(datos$"ID"))
length(biomarcadores$"ID")
length(unique(biomarcadores$"ID"))

datos2<-merge(datos,biomarcadores,by="ID",all.x=T)

# 16. Crea una base de datos en formato "long" con tres variables: ID de registro, biomarcador medido y valor de este.


datos_long<-reshape(datos2[,c("ID","Al","Hg","Cd","Be", "Se","Cu","As")],v.names = "conc",
varying=c("Al","Hg","Cd","Be", "Se","Cu","As"),idvar="ID",times=c("Al","Hg","Cd","Be", "Se","Cu","As"),direction="long",
timevar = "Biomarcador")

row.names(datos_long)<-NULL


